import { Component } from '@angular/core';


@Component({
    templateUrl:"./paymentdetails.component.html",
    selector:"payment-details"
})
export class PaymentDetailsComponent{

}