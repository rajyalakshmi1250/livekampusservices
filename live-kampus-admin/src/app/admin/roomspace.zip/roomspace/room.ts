export class Room{
    
    
    
    roomName: String;
    roomAddress: String;
    roomArea: number;
    roomDeposit: number;
    roomRent: number;
    roomType: String;
    wifi: String;
    available: String;
    fullFurnished: String;


}